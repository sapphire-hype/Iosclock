# IosClock – an iOS 16 style Clock app for Android

Native Kotlin + Jetpack Compose. Five tabs: World Clock, Alarm, Bedtime, Stopwatch, Timer.

## Build
1. Open this folder in Android Studio (Koala or newer, JDK 17). Let it sync; it will create the Gradle wrapper.
2. Run on a device or emulator (minSdk 26).
3. On Android 13+, allow notifications when prompted so alarms and timers can ring.

## Notes
- Alarms and timers use `AlarmManager.setAlarmClock`, so no exact-alarm permission is needed. They fire a high-priority notification with the alarm sound and vibration.
- Alarms are rescheduled after reboot.
- Bedtime's "Sleep Schedule" switch creates a daily "Wake Up" alarm that also appears in the Alarm tab.
- This is an independent look-alike: it uses the system font and Material icons, not Apple's SF fonts or assets.

## Build an APK without installing anything
1. Create a new GitHub repository and upload the contents of this folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or press "Run workflow").
3. When it finishes, open the run and download **IosClock-debug-apk** from Artifacts. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and install it (allow "install unknown apps" when asked).
