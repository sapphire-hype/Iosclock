package com.example.iosclock.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.alarm.AlarmItem
import com.example.iosclock.alarm.AlarmScheduler
import com.example.iosclock.alarm.AlarmStore
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private const val WAKE_ALARM_ID = 1001

private object BedtimeStore {
    private fun p(c: Context) = c.getSharedPreferences("bedtime", Context.MODE_PRIVATE)
    fun bed(c: Context) = p(c).getInt("bed", 22 * 60 + 30)
    fun wake(c: Context) = p(c).getInt("wake", 6 * 60 + 30)
    fun enabled(c: Context) = p(c).getBoolean("on", false)
    fun save(c: Context, bed: Int, wake: Int, on: Boolean) {
        p(c).edit().putInt("bed", bed).putInt("wake", wake).putBoolean("on", on).apply()
    }
}

private fun fmt(min: Int): String {
    val h = min / 60
    val m = min % 60
    return "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")
}

private fun minutesToAngle(m: Int): Double = m / 1440.0 * 2 * PI - PI / 2

@Composable
fun BedtimeScreen() {
    val ctx = LocalContext.current
    var bed by remember { mutableIntStateOf(BedtimeStore.bed(ctx)) }
    var wake by remember { mutableIntStateOf(BedtimeStore.wake(ctx)) }
    var enabled by remember { mutableStateOf(BedtimeStore.enabled(ctx)) }

    /** Persist the settings and keep the daily "Wake Up" alarm in the Alarm tab in sync. */
    fun sync() {
        BedtimeStore.save(ctx, bed, wake, enabled)
        val rest = AlarmStore.load(ctx).filter { it.id != WAKE_ALARM_ID }
        if (enabled) {
            val a = AlarmItem(
                WAKE_ALARM_ID, wake / 60, wake % 60, "Wake Up",
                setOf(
                    Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
                    Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY,
                ),
                true,
            )
            AlarmStore.save(ctx, rest + a)
            AlarmScheduler.schedule(ctx, a)
        } else {
            AlarmStore.save(ctx, rest)
            AlarmScheduler.cancel(ctx, WAKE_ALARM_ID)
        }
    }

    val sleepMin = ((wake - bed) % 1440 + 1440) % 1440

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ScreenHeader("Bedtime")
        Text(
            "${sleepMin / 60} hr ${sleepMin % 60} min",
            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 16.dp),
        )
        Text("Sleep goal", color = IosGray, fontSize = 14.sp)

        SleepDial(
            bed = bed, wake = wake,
            onBed = { bed = it },
            onWake = { wake = it },
            onDragEnd = { sync() },
            modifier = Modifier.padding(vertical = 16.dp),
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text("BEDTIME", color = IosGray, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(fmt(bed), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("WAKE UP", color = IosGray, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(fmt(wake), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(12.dp)).background(IosCard)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Sleep Schedule", color = Color.White, fontSize = 17.sp)
                Text("Every day, wake-up alarm at ${fmt(wake)}", color = IosGray, fontSize = 13.sp)
            }
            Switch(
                checked = enabled,
                onCheckedChange = { enabled = it; sync() },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = IosGreen, checkedThumbColor = Color.White,
                    checkedBorderColor = IosGreen,
                    uncheckedTrackColor = IosDarkGray, uncheckedThumbColor = Color.White,
                    uncheckedBorderColor = IosDarkGray,
                ),
            )
        }
    }
}

@Composable
private fun SleepDial(
    bed: Int,
    wake: Int,
    onBed: (Int) -> Unit,
    onWake: (Int) -> Unit,
    onDragEnd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val dialSize = 300.dp
    val trackW = 44.dp
    val sizePx = with(density) { dialSize.toPx() }
    val trackPx = with(density) { trackW.toPx() }
    val ringR = sizePx / 2 - trackPx / 2 - with(density) { 4.dp.toPx() }
    val iconHalf = with(density) { 12.dp.toPx() }.roundToInt()
    val measurer = rememberTextMeasurer()
    // pointerInput(Unit) below never restarts, so read the latest values through these.
    val bedNow by rememberUpdatedState(bed)
    val wakeNow by rememberUpdatedState(wake)
    val onBedNow by rememberUpdatedState(onBed)
    val onWakeNow by rememberUpdatedState(onWake)
    val onEndNow by rememberUpdatedState(onDragEnd)

    fun handlePos(m: Int): Offset {
        val a = minutesToAngle(m)
        return Offset(sizePx / 2 + (ringR * cos(a)).toFloat(), sizePx / 2 + (ringR * sin(a)).toFloat())
    }

    Box(modifier.size(dialSize)) {
        var active by remember { mutableIntStateOf(0) } // 0 = bed, 1 = wake
        Canvas(
            Modifier.fillMaxSize().pointerInput(Unit) {
                fun toMinutes(p: Offset): Int {
                    var a = atan2((p.y - size.height / 2f).toDouble(), (p.x - size.width / 2f).toDouble()) + PI / 2
                    if (a < 0) a += 2 * PI
                    return ((a / (2 * PI) * 1440 / 5).roundToInt() * 5) % 1440
                }
                detectDragGestures(
                    onDragStart = { p ->
                        val m = toMinutes(p)
                        fun dist(x: Int): Int {
                            val d = Math.abs(x - m)
                            return min(d, 1440 - d)
                        }
                        active = if (dist(bedNow) <= dist(wakeNow)) 0 else 1
                    },
                    onDragEnd = { onEndNow() },
                    onDragCancel = { onEndNow() },
                ) { change, _ ->
                    change.consume()
                    val m = toMinutes(change.position)
                    if (active == 0) onBedNow(m) else onWakeNow(m)
                }
            }
        ) {
            val inset = trackPx / 2 + 4.dp.toPx()
            val arcSize = Size(size.width - 2 * inset, size.height - 2 * inset)
            drawArc(
                IosCard, 0f, 360f, false,
                topLeft = Offset(inset, inset), size = arcSize, style = Stroke(trackPx),
            )
            // Hour ticks every 15 minutes' worth of dial (every 2 hours drawn bolder).
            for (i in 0 until 96) {
                val a = i / 96.0 * 2 * PI - PI / 2
                val r1 = ringR - trackPx / 2 - 6.dp.toPx()
                val len = if (i % 8 == 0) 8.dp.toPx() else 4.dp.toPx()
                drawLine(
                    if (i % 8 == 0) Color.White else IosGray,
                    Offset(center.x + (r1 * cos(a)).toFloat(), center.y + (r1 * sin(a)).toFloat()),
                    Offset(center.x + ((r1 - len) * cos(a)).toFloat(), center.y + ((r1 - len) * sin(a)).toFloat()),
                    strokeWidth = 1.5.dp.toPx(),
                )
            }
            val startDeg = (bed / 1440f) * 360f - 90f
            val sweep = (((wake - bed) % 1440 + 1440) % 1440) / 1440f * 360f
            drawArc(
                IosOrange, startDeg, sweep, false,
                topLeft = Offset(inset, inset), size = arcSize,
                style = Stroke(trackPx, cap = StrokeCap.Round),
            )
            listOf("12 AM" to 0, "6 AM" to 360, "12 PM" to 720, "6 PM" to 1080).forEach { (t, m) ->
                val a = minutesToAngle(m)
                val r = ringR - trackPx / 2 - 36.dp.toPx()
                val layout = measurer.measure(t, TextStyle(color = IosGray, fontSize = 12.sp))
                drawText(
                    layout,
                    topLeft = Offset(
                        center.x + (r * cos(a)).toFloat() - layout.size.width / 2f,
                        center.y + (r * sin(a)).toFloat() - layout.size.height / 2f,
                    ),
                )
            }
        }
        val bp = handlePos(bed)
        val wp = handlePos(wake)
        Icon(
            Icons.Filled.Bed, "Bedtime", tint = Color.Black,
            modifier = Modifier.size(24.dp).offset { IntOffset(bp.x.roundToInt() - iconHalf, bp.y.roundToInt() - iconHalf) },
        )
        Icon(
            Icons.Filled.Alarm, "Wake up", tint = Color.Black,
            modifier = Modifier.size(24.dp).offset { IntOffset(wp.x.roundToInt() - iconHalf, wp.y.roundToInt() - iconHalf) },
        )
    }
}
