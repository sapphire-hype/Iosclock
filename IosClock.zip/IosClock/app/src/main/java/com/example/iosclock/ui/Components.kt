package com.example.iosclock.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.filter

@Composable
fun ScreenHeader(
    title: String,
    left: (@Composable () -> Unit)? = null,
    right: (@Composable () -> Unit)? = null,
) {
    Column(Modifier.statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().height(44.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box { left?.invoke() }
            Box { right?.invoke() }
        }
        Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
fun OrangeTextButton(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) {
        Text(text, color = IosOrange, fontSize = 17.sp)
    }
}

/** iOS-style round button with an outer ring. */
@Composable
fun CircleButton(
    label: String,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier.size(88.dp).border(2.dp, bg.copy(alpha = if (enabled) 1f else 0.5f), CircleShape).padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(80.dp).clip(CircleShape).background(bg)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, color = if (enabled) fg else fg.copy(alpha = 0.5f), fontSize = 17.sp)
        }
    }
}

/** Snapping vertical wheel, similar to the iOS picker. Reports the value when scrolling settles. */
@Composable
fun WheelPicker(
    range: IntRange,
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    format: (Int) -> String = { it.toString() },
    suffix: String? = null,
) {
    val itemH = 40.dp
    val items = remember(range) { range.toList() }
    val state = rememberLazyListState(
        initialFirstVisibleItemIndex = (value - range.first).coerceIn(0, items.lastIndex)
    )
    val fling = rememberSnapFlingBehavior(state)
    val itemPx = with(LocalDensity.current) { itemH.toPx() }
    val selected by remember {
        derivedStateOf {
            (state.firstVisibleItemIndex + if (state.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0)
                .coerceIn(0, items.lastIndex)
        }
    }
    val latest by rememberUpdatedState(onValueChange)
    LaunchedEffect(state) {
        snapshotFlow { state.isScrollInProgress }.filter { !it }.collect { latest(items[selected]) }
    }

    Box(modifier.height(itemH * 5)) {
        Box(
            Modifier.align(Alignment.Center).fillMaxWidth().height(itemH)
                .clip(RoundedCornerShape(8.dp)).background(IosWheelHighlight)
        )
        LazyColumn(
            state = state,
            flingBehavior = fling,
            contentPadding = PaddingValues(vertical = itemH * 2),
            modifier = Modifier.fillMaxWidth(),
        ) {
            itemsIndexed(items) { idx, v ->
                Row(
                    Modifier.fillMaxWidth().height(itemH),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        format(v),
                        fontSize = 22.sp,
                        color = if (idx == selected) Color.White else IosGray,
                    )
                    if (suffix != null && idx == selected) {
                        Text(" $suffix", fontSize = 14.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
