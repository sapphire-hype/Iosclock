package com.example.iosclock.alarm

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.iosclock.MainActivity
import java.util.Calendar
import java.util.Locale

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getStringExtra("kind")) {
            "alarm" -> {
                val id = i.getIntExtra("id", 0)
                val list = AlarmStore.load(c)
                val a = list.find { it.id == id } ?: return
                val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute) }
                val text = String.format(
                    Locale.getDefault(), "%d:%02d %s",
                    if (a.hour % 12 == 0) 12 else a.hour % 12, a.minute,
                    if (cal.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
                )
                Notifier.post(c, id, a.label.ifBlank { "Alarm" }, text)
                if (a.days.isEmpty()) {
                    AlarmStore.save(c, list.map { if (it.id == id) it.copy(enabled = false) else it })
                } else {
                    AlarmScheduler.schedule(c, a)
                }
            }
            "timer" -> Notifier.post(c, AlarmScheduler.TIMER_ID, "Timer", "Time's up")
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) AlarmScheduler.rescheduleAll(c)
    }
}

object Notifier {
    private const val CHANNEL = "alarms"

    fun post(c: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Alarms & Timers", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(
                    sound,
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
            }
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}
