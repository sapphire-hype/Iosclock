package com.example.iosclock.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.iosclock.MainActivity
import java.util.Calendar

object AlarmScheduler {
    const val TIMER_ID = -1

    fun nextTrigger(a: AlarmItem, from: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        for (offset in 0..7) {
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, offset)
            cal.set(Calendar.HOUR_OF_DAY, a.hour)
            cal.set(Calendar.MINUTE, a.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val dayOk = a.days.isEmpty() || cal.get(Calendar.DAY_OF_WEEK) in a.days
            if (dayOk && cal.timeInMillis > from) return cal.timeInMillis
        }
        return from + 24L * 3600 * 1000
    }

    fun schedule(c: Context, a: AlarmItem) {
        if (!a.enabled) {
            cancel(c, a.id)
            return
        }
        setClock(c, nextTrigger(a), pending(c, a.id, "alarm"))
    }

    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, id, if (id == TIMER_ID) "timer" else "alarm"))
    }

    fun scheduleTimer(c: Context, triggerAtMillis: Long) =
        setClock(c, triggerAtMillis, pending(c, TIMER_ID, "timer"))

    fun cancelTimer(c: Context) = cancel(c, TIMER_ID)

    fun rescheduleAll(c: Context) {
        AlarmStore.load(c).forEach { schedule(c, it) }
    }

    private fun setClock(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock is exempt from exact-alarm permission requirements.
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
    }

    private fun pending(c: Context, id: Int, kind: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("kind", kind).putExtra("id", id)
        return PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
